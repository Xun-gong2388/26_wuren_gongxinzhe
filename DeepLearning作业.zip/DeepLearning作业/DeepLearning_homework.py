import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision import datasets
import matplotlib.pyplot as plt

# 自动检测可用设备（GPU优先，无GPU则用CPU）
device = torch.device('cuda' 
     if 
      torch.cuda.is_available() 
     else 
      'cpu'
)
print(f'使用设备: {device}')

#制作数据集
#把图像转化为张量
transform = transforms.Compose([
    transforms.Resize((128, 128)),          # 统一缩放到128×128
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.5, 0.5, 0.5], 
        std=[0.5, 0.5, 0.5]) 
    ])

#加载数据
train_dataset = datasets.ImageFolder(#这里要处理彩色图像，所以用ImageFolder，而不是MNIST
    root='DeepLearning作业/train',
    transform=transform
    )
test_dataset1 = datasets.ImageFolder(
    root='DeepLearning作业/test1',
    transform=transform
    )
test_dataset2 = datasets.ImageFolder(
    root='DeepLearning作业/test2',
    transform=transform
    )

#批次加载，这样可以提高效率
train_loader = DataLoader(
    train_dataset,
    shuffle=True,#训练集需要打乱顺序，来让模型更准确
    batch_size=64
    )
test_loader1 = DataLoader(
    test_dataset1,
    shuffle=False,#测试集打乱顺序与否没有影响
    batch_size=64
    )
test_loader2 = DataLoader(
    test_dataset2,
    shuffle=False,
    batch_size=64
    )  

'''
计算图片尺寸
from PIL import Image
img = Image.open('DeepLearning作业/train/blue/blue_1.png')
width, height = img.size          # (宽, 高)
channels = len(img.getbands())    # 3 表示 RGB, 1 表示灰度
print(f"尺寸: {width}×{height}, 通道数: {channels}")
# 结果：尺寸128*128，通道数3
'''
#2卷积，2全连接
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            # 输入: 3×128×128
            nn.Conv2d(3, 16, kernel_size=3, padding=1), nn.ReLU(),   # 3×128×128->16×128×128
            nn.AvgPool2d(2, 2),                                      # 16×128×128->16×64×64
            nn.Conv2d(16, 32, kernel_size=3, padding=1), nn.ReLU(),  # 16×64×64->32×64×64
            nn.AvgPool2d(2, 2),                                      # 32×64×64->32×32×32    
            nn.AdaptiveAvgPool2d((1,1)),                             # 32×32×32->32×1×1
            nn.Flatten(),                                            # 32×1×1->32  
            nn.Linear(32, 16), nn.ReLU(),                            # 32->16
            nn.Linear(16, 3)                                         # 16->3
        )
    def forward(self, x):
        y = self.net(x)
        return y

'''
只使用全连接层
#搭建神经网络
class DNN(nn.Module):
    def __init__(self):
        #搭建神经网络各层
        super(DNN,self).__init__()
        self.net=nn.Sequential(
            nn.Flatten(),#把图像展开成一维向量，方便后续计算
            nn.Linear(49152,784),nn.ReLU(),
            nn.Linear(784,128),nn.ReLU(),
            nn.Linear(128,3),nn.ReLU()
        )
    def forward(self,x):
        #前向传播
        y=self.net(x)
        return y
'''
#把子类放到相应设备上
model=CNN().to(device)

#损失函数
loss_fn=nn.CrossEntropyLoss()
#优化算法
learning_rate=0.001#学习率
optimizer=torch.optim.Adam(
    model.parameters(),
    lr=learning_rate
    )

#训练网络
epoch=30
losses=[]
for i in range(epoch):
    for (x,y) in train_loader:
        x=x.to(device)
        y=y.to(device)
        #一次前向传播得到的输出值
        Pred=model(x)
        #计算损失
        loss=loss_fn(Pred,y)
        #记录损失函数变化
        losses.append(loss.item())
        #清理滞留的梯度
        optimizer.zero_grad()
        #反向传播
        loss.backward()
        optimizer.step()
        
#可视化损失函数变化
Fig=plt.figure()
plt.plot(range(len(losses)),losses)
plt.savefig('loss_curve.png')  # 保存图片
plt.close()                    # 关闭窗口，避免阻塞
print('损失曲线已保存为 loss_curve.png')

#测试模型
correct=0
total=0
with torch.no_grad():
    for (x,y) in test_loader1:
        x=x.to(device)
        y=y.to(device)
        #一次前向传播得到的输出值
        Pred=model(x)
        loss=loss_fn(Pred,y)
        _, predicted = torch.max(Pred.data, dim=1)
        correct += torch.sum( (predicted == y) )
        total += y.size(0)
print(f'测试集1准确率: {100*correct.item()/total}%')

# 重置统计变量，单独计算测试集2的准确率
correct = 0
total = 0
with torch.no_grad():
    for (x,y) in test_loader2:
        x=x.to(device)
        y=y.to(device)
        #一次前向传播得到的输出值
        Pred=model(x)
        loss=loss_fn(Pred,y)
        _, predicted = torch.max(Pred.data, dim=1)
        correct += torch.sum( (predicted == y) )
        total += y.size(0)
print(f'测试集2准确率: {100*correct.item()/total}%')
       